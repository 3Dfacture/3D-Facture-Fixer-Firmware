/*Fixer Beta Version,  Copyright:  3D Facture LLC 2016*/
#ifndef _PIN_H
#define _PIN_H
#define ONOFF_CON 0/*this pin is set to be LOW when it's  started*/
#define ONOFF_CHK 1/*this pin is HIGH when it's on work*/

#define LED1 4
#define LED2 3
#define LED3 2
#define LED4 33/*four LED pin*/

#define CHARGE_V_VALUE 5/*charging voltage*/
#define CHARGE_V_STAT0 6
#define CHARGE_V_STAT1 7/*when CHARGE_V_STAT0==1&&CHARGE_V_STAT1==0,power's charged*/

#define UVLED_INPUT  17
#define UVLED_OUTPUT 18/*Curing LED's input/output pin*/

#define MOVE_BACK    19
#define MOVE_FORWARD 20/*motor move back/forward*/

#define FORWARD_LIMIT 21
#define BACK_LIMIT    22/*limit motor to move*/

#define EXTRUDE_CON_BIT0 28
#define EXTRUDE_CON_BIT1 29/*the two pins control extrude speed*/

#define MOTOR_SLEEP 12
#define MOTOR_VINT 13
#define MOTOR_DIR    14
#define MOTOR_STEP   15
#define MOTOR_ENABLE 16
int LedPin[4]={LED1,LED2,LED3,LED4};
#endif
