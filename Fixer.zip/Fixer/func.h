/*Fixer Beta Version,  Copyright:  3D Facture LLC 2016*/
#ifndef _FUNC_H
#define _FUNC_H
#include <string.h>
#include <stdlib.h>
/*declare function*/
void InitPin();
void TurnOnAllLed(void);
void TurnOffAllLed(void);
void ShiningAllLED(int);
void SetUp();
void ShutDown(void);
void AutoShutDown(void);
void CountToShutDown(void);
short ReadChargeState(void);
void LightUpLED(short);
void ShowPowerStus();
void LightUpUVLED(short msec);

bool ManageUVLED(void);
void Extrude(short dir,short workmode);
bool ManageMotor(void);
void WorkInNormalMode(void);

void ParseCommandFromComputer(char* command);
void WorkInComputerConctrolMode(void);
#endif
