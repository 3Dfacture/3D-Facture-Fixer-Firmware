/*Fixer Beta Version,  Copyright:  3D Facture LLC 2016*/
#ifndef _SET_H
#define _SET_H
/*you can change some functions conveniently by changing some variables in this file*/
#define MOTOR_PULSES_FACTOR 20
#define MOTOR_SPEED 800
#define MOTOR_STEP_DOHV 50/*serial factors of motor*/

#define EXTRUDE_LAST_DIR_TIMES 4/*press the Forward-Button for a while,it'll extrude contiously */

/*#define LST_SPL_VLT 1800 /*Motor's minimum working voltage is 1800mv*/
#define LST_SPL_VLT 100 /*Reduce Motor's minimum working voltage is 100mv*/

#define POWER_CHARGE_LEV0 2500
#define POWER_CHARGE_LEV1 2900
#define POWER_CHARGE_LEV2 3200
#define UVLED_RATE 3000  /*CuringLight's lasting time is 3000ms*/
#define AUTO_SHUT_DOWN_TIME 5//5 min later ,automatically shut down
#define TIMER_COUNT_RATE 500000//0.5 s the timer counts once

#define COMMANDLEN 256
#define NORMAL_MODE  0
#define CONTROL_MODE 1
#endif
